package metier;

public interface IMetier {
    double calcule() ;
}
