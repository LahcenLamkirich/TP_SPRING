package metier;

public class Calcule {
    // la declaration de la fonction

    int Somme(int a, int b) {
        return a + b ;
    }
}
